import 'package:flutter/material.dart';
import '../theme/app_theme.dart';

/// Only list real, supported DeepSeek API model IDs.
class ModelSelectionDialog extends StatelessWidget {
  final String currentModel;
  final ValueChanged<String> onModelSelected;
  const ModelSelectionDialog({super.key, required this.currentModel, required this.onModelSelected});

  static Future<String?> show(BuildContext context, {required String currentModel}) =>
      showDialog<String>(
        context: context,
        builder: (_) => ModelSelectionDialog(
          currentModel: currentModel,
          onModelSelected: (model) => Navigator.of(context).pop(model),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final chinese = Localizations.localeOf(context).languageCode == 'zh';
    return AlertDialog(
      backgroundColor: AppTheme.deepIndigo,
      title: Text(chinese ? '选择 DeepSeek 模型' : 'Choose DeepSeek model',
          style: const TextStyle(color: Colors.white)),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        _choice(context, 'deepseek-flash', 'DeepSeek Flash',
            chinese ? '推荐 · 日常交流，响应较快' : 'Recommended · Fast everyday chat'),
        _choice(context, 'deepseek-v4-pro', 'DeepSeek V4 Pro',
            chinese ? '适合复杂任务和深度对话' : 'Complex tasks and deeper conversations'),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(context),
          child: Text(chinese ? '取消' : 'Cancel'))],
    );
  }

  Widget _choice(BuildContext context, String id, String name, String subtitle) =>
      ListTile(
        leading: Icon(
          id == currentModel ? Icons.radio_button_checked : Icons.radio_button_unchecked,
          color: AppTheme.warmGold,
        ),
        title: Text(name, style: const TextStyle(color: Colors.white)),
        subtitle: Text(subtitle, style: const TextStyle(color: Colors.white70)),
        onTap: () => onModelSelected(id),
      );
}
