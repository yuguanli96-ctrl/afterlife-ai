import 'dart:io' show Platform;
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:provider/provider.dart';

import '../../l10n/app_localizations.dart';
import '../models/character_model.dart';
import '../providers/characters_provider.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/ukrainian_font_utils.dart';
import '../../core/utils/image_utils.dart';
import '../settings/settings_screen.dart';
import '../character_interview/interview_screen.dart';
import '../character_chat/chat_screen.dart';
import '../character_prompts/famous_character_profile_screen.dart';
import '../group_chat/group_chat_screen.dart';
import '../group_chat/models/group_chat_model.dart';
import '../group_chat/character_selection_screen.dart';
import '../providers/group_chat_provider.dart';
import '../../core/utils/responsive_utils.dart';
// ignore: unused_import
import '../widgets/background_painters.dart'; // used by StarfieldPainter below
import '../../core/widgets/adaptive_text.dart';

class PulseRingPainter extends CustomPainter {
  final double progress;
  final Color color;

  PulseRingPainter({required this.progress, required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final Paint paint =
        Paint()
          ..color = color.withValues(alpha: 0.3 * (1 - progress))
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.0 * (1 + progress);

    final double radius = size.width / 2 * (0.8 + progress * 0.2);
    final Offset center = Offset(size.width / 2, size.height / 2);

    canvas.drawCircle(center, radius, paint);
  }

  @override
  bool shouldRepaint(PulseRingPainter oldDelegate) {
    return oldDelegate.progress != progress || oldDelegate.color != color;
  }
}

class CharacterGalleryScreen extends StatefulWidget {
  const CharacterGalleryScreen({Key? key}) : super(key: key);

  @override
  State<CharacterGalleryScreen> createState() => _CharacterGalleryScreenState();
}

class _CharacterGalleryScreenState extends State<CharacterGalleryScreen>
    with SingleTickerProviderStateMixin {
  int _selectedIndex = 0;
  late final PageController _pageController;

  // Add scroll controllers for each tab
  late final ScrollController _exploreScrollController;
  late final ScrollController _yourTwinsScrollController;
  late final ScrollController _groupChatsScrollController;

  // Animation controller for header visibility
  late final AnimationController _headerAnimationController;
  late final Animation<double> _headerOpacityAnimation;
  late final Animation<double> _headerHeightAnimation;

  bool _isHeaderVisible = true;

  @override
  void initState() {
    super.initState();
    _pageController = PageController();

    // Initialize scroll controllers
    _exploreScrollController = ScrollController();
    _yourTwinsScrollController = ScrollController();
    _groupChatsScrollController = ScrollController();

    // Initialize header animation controller
    _headerAnimationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );

    _headerOpacityAnimation = Tween<double>(begin: 1.0, end: 0.0).animate(
      CurvedAnimation(
        parent: _headerAnimationController,
        curve: Curves.easeInOut,
      ),
    );

    _headerHeightAnimation = Tween<double>(begin: 1.0, end: 0.0).animate(
      CurvedAnimation(
        parent: _headerAnimationController,
        curve: Curves.easeInOut,
      ),
    );

    // Add scroll listeners
    _exploreScrollController.addListener(_onScroll);
    _yourTwinsScrollController.addListener(_onScroll);
    _groupChatsScrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    _pageController.dispose();
    _exploreScrollController.dispose();
    _yourTwinsScrollController.dispose();
    _groupChatsScrollController.dispose();
    _headerAnimationController.dispose();
    super.dispose();
  }

  void _onScroll() {
    final ScrollController currentController =
        _selectedIndex == 0
            ? _exploreScrollController
            : _selectedIndex == 1
                ? _yourTwinsScrollController
                : _groupChatsScrollController;

    if (!currentController.hasClients) return;

    const double hideRange = 120.0; // pixels to fully hide header
    final double clampedOffset =
        currentController.offset.clamp(0.0, hideRange);
    final double targetValue = (clampedOffset / hideRange).clamp(0.0, 1.0);
    _headerAnimationController.animateTo(
      targetValue,
      duration: const Duration(milliseconds: 120),
      curve: Curves.easeOut,
    );
  }

  // Cache text styles for potential future reuse (kept for theme consistency)
  // ignore: unused_field
  late final TextStyle _titleStyle = AppTheme.titleStyle;
  // ignore: unused_field
  late final TextStyle _subtitleStyle = AppTheme.subtitleStyle;
  // ignore: unused_field
  late final TextStyle _captionStyle = AppTheme.captionStyle;

  // Cached bottom navigation items for better performance
  List<BottomNavigationBarItem> _getNavigationItems(
    AppLocalizations localizations,
  ) {
    return [
      BottomNavigationBarItem(
        icon: const Icon(Icons.explore, size: 24),
        label: localizations.explore,
      ),
      BottomNavigationBarItem(
        icon: const Icon(Icons.person_outline, size: 24),
        label: localizations.yourTwins,
      ),
      BottomNavigationBarItem(
        icon: const Icon(Icons.group, size: 24),
        label: localizations.groupChats,
      ),
      BottomNavigationBarItem(
        icon: const Icon(Icons.add_circle_outline, size: 24),
        label: localizations.create,
      ),
      BottomNavigationBarItem(
        icon: const Icon(Icons.settings, size: 24),
        label: localizations.settings,
      ),
    ];
  }

  // Sample famous people for the Explore tab - using const for better performance
  List<Map<String, dynamic>> _getFamousPeople(AppLocalizations localizations) {
    return [
      {
        'name': 'Albert Einstein',
        'years': '1879-1955',
        'profession': localizations.physicist,
        'imageUrl': 'assets/images/einstein.png',
      },
      {
        'name': 'Ronald Reagan',
        'years': '1911-2004',
        'profession': localizations.presidentActor,
        'imageUrl': 'assets/images/reagan.png',
      },
      {
        'name': 'Alan Turing',
        'years': '1912-1954',
        'profession': localizations.computerScientist,
        'imageUrl': 'assets/images/turing.png',
      },
      {
        'name': 'Marilyn Monroe',
        'years': '1926-1962',
        'profession': localizations.actressModelSinger,
        'imageUrl': 'assets/images/monroe.png',
      },
      {
        'name': 'Kobe Bryant',
        'years': '1978-2020',
        'profession': localizations.basketballPlayer,
        'imageUrl': 'assets/images/kobe_bryant.png',
      },
      {
        'name': 'Kurt Cobain',
        'years': '1967-1994',
        'profession': localizations.musicianSinger,
        'imageUrl': 'assets/images/kurt_cobain.png',
      },
      {
        'name': 'Nelson Mandela',
        'years': '1918-2013',
        'profession': localizations.politicalLeaderActivist,
        'imageUrl': 'assets/images/nelson_mandela.png',
      },
      {
        'name': 'Bob Marley',
        'years': '1945-1981',
        'profession': localizations.musicianSinger,
        'imageUrl': 'assets/images/bob_marley.png',
      },
      {
        'name': 'Bruce Lee',
        'years': '1940-1973',
        'profession': localizations.martialArtistActor,
        'imageUrl': 'assets/images/bruce_lee.png',
      },
      {
        'name': 'Martin Luther King Jr.',
        'years': '1929-1968',
        'profession': localizations.civilRightsLeader,
        'imageUrl': 'assets/images/martin_luther.png',
      },
      {
        'name': 'Marie Curie',
        'years': '1867-1934',
        'profession': localizations.physicistChemist,
        'imageUrl': 'assets/images/marie_curie.png',
      },
      {
        'name': 'Abraham Lincoln',
        'years': '1809-1865',
        'profession': localizations.usPresident,
        'imageUrl': 'assets/images/abraham_lincoln.png',
      },
      {
        'name': 'Cleopatra',
        'years': '69-30 BC',
        'profession': localizations.egyptianPharaoh,
        'imageUrl': 'assets/images/cleopatra.png',
      },
      {
        'name': 'Avicii',
        'years': '1989-2018',
        'profession': localizations.djMusicProducer,
        'imageUrl': 'assets/images/avici.png',
      },
      {
        'name': 'Tupac Shakur',
        'years': '1971-1996',
        'profession': localizations.rapperActor,
        'imageUrl': 'assets/images/tupac.png',
      },
      {
        'name': 'David Bowie',
        'years': '1947-2016',
        'profession': localizations.musicianArtist,
        'imageUrl': 'assets/images/david_bowie.png',
      },
      {
        'name': 'Stephen Hawking',
        'years': '1942-2018',
        'profession': localizations.theoreticalPhysicist,
        'imageUrl': 'assets/images/stephen_hawking.png',
      },
      {
        'name': 'Elvis Presley',
        'years': '1935-1977',
        'profession': localizations.singerActor,
        'imageUrl': 'assets/images/elvis_presley.png',
      },
      {
        'name': 'Winston Churchill',
        'years': '1874-1965',
        'profession': localizations.britishPrimeMinister,
        'imageUrl': 'assets/images/winston_churchill.png',
      },
      {
        'name': 'Nikola Tesla',
        'years': '1856-1943',
        'profession': localizations.inventorEngineer,
        'imageUrl': 'assets/images/nikola_tesla.png',
      },
      {
        'name': 'William Shakespeare',
        'years': '1564-1616',
        'profession': localizations.playwrightPoet,
        'imageUrl': 'assets/images/william_shakespeare.png',
      },
      {
        'name': 'Julius Caesar',
        'years': '100-44 BC',
        'profession': localizations.romanGeneralDictator,
        'imageUrl': 'assets/images/caesar.png',
      },
      {
        'name': 'Steve Jobs',
        'years': '1955-2011',
        'profession': localizations.techEntrepreneur,
        'imageUrl': 'assets/images/steve_jobs.png',
      },
      {
        'name': 'Princess Diana',
        'years': '1961-1997',
        'profession': localizations.britishRoyalHumanitarian,
        'imageUrl': 'assets/images/diana_princess.png',
      },
      {
        'name': 'Freddie Mercury',
        'years': '1946-1991',
        'profession': localizations.singerPerformer,
        'imageUrl': 'assets/images/freddie_mercury.png',
      },
      {
        'name': 'Muhammad Ali',
        'years': '1942-2016',
        'profession': localizations.boxerActivist,
        'imageUrl': 'assets/images/muhammad_ali.png',
      },
      {
        'name': 'Carl Sagan',
        'years': '1934-1996',
        'profession': localizations.astronomerScienceCommunicator,
        'imageUrl': 'assets/images/carl_sagan.png',
      },
      {
        'name': 'Mahatma Gandhi',
        'years': '1869-1948',
        'profession': localizations.independenceLeader,
        'imageUrl': 'assets/images/gandhi.png',
      },
      {
        'name': 'Vincent van Gogh',
        'years': '1853-1890',
        'profession': localizations.painter,
        'imageUrl': 'assets/images/vincent_van_gogh.png',
      },
      {
        'name': 'Leonardo da Vinci',
        'years': '1452-1519',
        'profession': localizations.polymathArtist,
        'imageUrl': 'assets/images/da_vinci.png',
      },
      {
        'name': 'Socrates',
        'years': '470-399 BC',
        'profession': localizations.philosopher,
        'imageUrl': 'assets/images/socrates.png',
      },
    ];
  }

  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations.of(context);
    final navigationItems = _getNavigationItems(localizations);
    final famousPeople = _getFamousPeople(localizations);

    return Scaffold(
      body: Stack(
        children: [
          // Background with gradient
          Container(
            decoration: const BoxDecoration(gradient: AppTheme.mainGradient),
          ),

          // Stars effect with reduced opacity - wrapped in RepaintBoundary for performance
          RepaintBoundary(
            child: CustomPaint(
              painter: StarfieldPainter(starCount: 80), // Reduced count
              size: Size.infinite,
            ),
          ),

          // Main content
          SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Animated header section
                AnimatedBuilder(
                  animation: _headerAnimationController,
                  builder: (context, child) {
                    return ClipRect(
                      child: SizeTransition(
                        sizeFactor: _headerHeightAnimation,
                        axisAlignment: -1.0,
                        child: FadeTransition(
                          opacity: _headerOpacityAnimation,
                          child: Padding(
                            padding: EdgeInsets.fromLTRB(
                              ResponsiveUtils.getScreenPadding(context).left,
                              32,
                              ResponsiveUtils.getScreenPadding(context).right,
                              24,
                            ),
                            child: AnimatedSwitcher(
                              duration: const Duration(milliseconds: 220),
                              switchInCurve: Curves.easeOut,
                              switchOutCurve: Curves.easeIn,
                              child: Text(
                                _selectedIndex == 0
                                    ? localizations.exploreDigitalTwins
                                    : _selectedIndex == 1
                                        ? localizations.yourDigitalTwins
                                        : localizations.groupChats,
                                key: ValueKey<int>(
                                  _selectedIndex <= 2 ? _selectedIndex : 0,
                                ),
                                style: UkrainianFontUtils
                                    .cinzelWithUkrainianSupport(
                                  text: _selectedIndex == 0
                                      ? localizations.exploreDigitalTwins
                                      : _selectedIndex == 1
                                          ? localizations.yourDigitalTwins
                                          : localizations.groupChats,
                                  fontSize: 24 *
                                      ResponsiveUtils.getFontSizeScale(
                                        context,
                                      ),
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 3.0,
                                  color: AppTheme.silverMist,
                                  shadows: [
                                    Shadow(
                                      blurRadius: 10.0,
                                      color: AppTheme.warmGold
                                          .withValues(alpha: 0.8),
                                      offset: const Offset(0, 2),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),

                // Main content area with PageView
                Expanded(
                  child: PageView(
                    controller: _pageController,
                    onPageChanged: (index) {
                      setState(() {
                        _selectedIndex = index;
                      });
                    },
                    children: [
                      _buildExploreTab(localizations, famousPeople),
                      _buildYourTwinsTab(localizations),
                      _buildGroupChatsTab(localizations),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      bottomNavigationBar: Theme(
        data: Theme.of(context).copyWith(
          textTheme: Theme.of(context).textTheme.copyWith(
            bodySmall: UkrainianFontUtils.latoWithUkrainianSupport(
              text: "Sample", // This will be used for tab labels
              fontSize: 11,
              fontWeight: FontWeight.w400,
            ),
          ),
        ),
        child: Container(
          decoration: BoxDecoration(
            color: AppTheme.midnightPurple.withValues(alpha: 0.8),
            border: Border(
              top: BorderSide(
                color: AppTheme.warmGold.withValues(alpha: 0.4),
                width: 1.5,
              ),
            ),
            boxShadow: [
              BoxShadow(
                color: AppTheme.deepNavy.withValues(alpha: 0.4),
                blurRadius: 15,
                spreadRadius: 0,
                offset: const Offset(0, -3),
              ),
              BoxShadow(
                color: AppTheme.warmGold.withValues(alpha: 0.1),
                blurRadius: 8,
                spreadRadius: 0,
                offset: const Offset(0, -1),
              ),
            ],
          ),
          child: BottomNavigationBar(
            currentIndex: _selectedIndex,
            onTap: _onTabTapped,
            backgroundColor: Colors.transparent,
            elevation: 0,
            type: BottomNavigationBarType.fixed,
            selectedLabelStyle: UkrainianFontUtils.latoWithUkrainianSupport(
              text: "Tab", // Placeholder text for style detection
              fontSize: 10,
              fontWeight: FontWeight.w500,
              color: AppTheme.warmGold,
              height: 1.1,
            ),
            unselectedLabelStyle: UkrainianFontUtils.latoWithUkrainianSupport(
              text: "Tab", // Placeholder text for style detection
              fontSize: 10,
              fontWeight: FontWeight.w400,
              color: AppTheme.silverMist.withValues(alpha: 0.5),
              height: 1.1,
            ),
            unselectedItemColor: AppTheme.silverMist.withValues(alpha: 0.5),
            selectedItemColor: AppTheme.warmGold,
            items: navigationItems,
          ),
        ),
      ),
    );
  }

  void _onTabTapped(int index) {
    // Animate to the selected page for the first 3 tabs (Explore, Your Twins, Group Chats)
    if (index < 3) {
      _pageController.animateToPage(
        index,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
      // Always show header smoothly when changing tabs
      _headerAnimationController.animateTo(
        0.0,
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeOut,
      );
      if (!_isHeaderVisible) {
        setState(() {
          _isHeaderVisible = true;
        });
      }
    }

    setState(() {
      _selectedIndex = index;
    });

    // Handle "Create" tab action
    if (index == 3) {
      // Defer navigation to next frame to avoid jank on tab tap
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _onAddCharacter(context);
      });
    }
    // Handle "Settings" tab action
    else if (index == 4) {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => const SettingsScreen()),
      ).then((_) {
        // Always return to Explore tab after settings
        _pageController.jumpToPage(0);
        setState(() {
          _selectedIndex = 0;
        });
        _headerAnimationController.animateTo(
          0.0,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
        if (!_isHeaderVisible) {
          setState(() {
            _isHeaderVisible = true;
          });
        }
      });
    }
  }

  // Explore tab with famous digital twins
  Widget _buildExploreTab(
    AppLocalizations localizations,
    List<Map<String, dynamic>> famousPeople,
  ) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Animated subtitle that also hides with the header
          AnimatedBuilder(
            animation: _headerAnimationController,
            builder: (context, child) {
              return ClipRect(
                child: SizeTransition(
                  sizeFactor: _headerHeightAnimation,
                  axisAlignment: -1.0,
                  child: FadeTransition(
                    opacity: _headerOpacityAnimation,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          localizations.interactWithHistoricalFigures,
                          style: UkrainianFontUtils.latoWithUkrainianSupport(
                            text: localizations.interactWithHistoricalFigures,
                            fontSize: 16,
                            color:
                                AppTheme.silverMist.withValues(alpha: 0.8),
                            letterSpacing: 0.5,
                          ),
                        ),
                        const SizedBox(height: 24),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
          Expanded(
            child:
                ResponsiveUtils.shouldUseWideLayout(context)
                    ? _buildHorizontalGallery(famousPeople, isExploreTab: true)
                    : _buildGridGallery(famousPeople, isExploreTab: true),
          ),
        ],
      ),
    );
  }

  // Group Chats tab with user's group conversations
  Widget _buildGroupChatsTab(AppLocalizations localizations) {
    return Consumer<GroupChatProvider>(
      builder: (context, provider, child) {
        if (provider.isLoading) {
          return Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(
                  width: 40,
                  height: 40,
                  child: CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation<Color>(
                      AppTheme.warmGold,
                    ),
                    strokeWidth: 2,
                    backgroundColor: AppTheme.deepNavy,
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  localizations.accessingDataStorage,
                  style: UkrainianFontUtils.cinzelWithUkrainianSupport(
                    text: localizations.accessingDataStorage,
                    fontSize: 14,
                    color: AppTheme.warmGold,
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
          );
        }

        if (provider.groupChats.isEmpty) {
          return _buildGroupChatsEmptyState(localizations);
        }

        final size = MediaQuery.of(context).size;
        final isLandscape = size.width > size.height;
        final deviceType = ResponsiveUtils.getDeviceType(context);
        // Only use grid in portrait. In landscape we want a horizontal scroller with big cards.
        final shouldUseGrid = !isLandscape && (
          deviceType == DeviceType.tablet ||
          deviceType == DeviceType.desktop ||
          deviceType == DeviceType.tv
        );
                             
        if (isLandscape) {
          // Landscape: horizontal row of large cards you can swipe through
          return Column(
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: _buildHorizontalGroupChats(provider, localizations),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(24),
                child: Center(child: _buildCreateGroupChatButton(localizations)),
              ),
            ],
          );
        }

        // Portrait: keep previous behavior (grid on tablets/desktop, list on mobile)
        return Column(
          children: [
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: _buildGroupChatsList(provider, localizations),
              ),
            ),
            Padding(
              padding: EdgeInsets.all(shouldUseGrid ? 24 : 20),
              child: shouldUseGrid
                  ? Center(child: _buildCreateGroupChatButton(localizations))
                  : _buildCreateGroupChatButton(localizations),
            ),
          ],
        );
      },
    );
  }

  Widget _buildGroupChatsEmptyState(AppLocalizations localizations) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.group_outlined,
            size: 80,
            color: AppTheme.warmGold.withValues(alpha: 0.5),
          ),
          const SizedBox(height: 24),
          Text(
            localizations.noGroupChats,
            style: UkrainianFontUtils.cinzelWithUkrainianSupport(
              text: localizations.noGroupChats,
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: AppTheme.warmGold,
              letterSpacing: 1.5,
            ),
          ),
          const SizedBox(height: 16),
          Text(
            localizations.createFirstGroup,
            style: UkrainianFontUtils.latoWithUkrainianSupport(
              text: localizations.createFirstGroup,
              fontSize: 16,
              color: AppTheme.silverMist.withValues(alpha: 0.8),
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 32),
          _buildCreateGroupChatButton(localizations),
        ],
      ),
    );
  }

  Widget _buildGroupChatsList(GroupChatProvider provider, AppLocalizations localizations) {
    // For Group Chats, use grid layout for tablets and above, even in portrait
    final deviceType = ResponsiveUtils.getDeviceType(context);
    final size = MediaQuery.of(context).size;
    final isLandscape = size.width > size.height;
    final shouldUseGrid = !isLandscape && (
      deviceType == DeviceType.tablet ||
      deviceType == DeviceType.desktop ||
      deviceType == DeviceType.tv
    );
    
    if (shouldUseGrid) {
      return GridView.builder(
        controller: _groupChatsScrollController,
        physics: const BouncingScrollPhysics(),
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: ResponsiveUtils.getGridCrossAxisCount(context),
          childAspectRatio: ResponsiveUtils.getGridChildAspectRatio(context),
          crossAxisSpacing: ResponsiveUtils.getGridSpacing(context),
          mainAxisSpacing: ResponsiveUtils.getGridSpacing(context),
        ),
        itemCount: provider.groupChats.length,
        itemBuilder: (context, index) {
          final group = provider.groupChats[index];
          return _buildGroupChatCard(group, localizations);
        },
      );
    } else {
      return ListView.builder(
        controller: _groupChatsScrollController,
        physics: const BouncingScrollPhysics(),
        itemCount: provider.groupChats.length,
        itemBuilder: (context, index) {
          final group = provider.groupChats[index];
          return _buildGroupChatCard(group, localizations);
        },
      );
    }
  }

  // Horizontal scroller with large square-ish group cards for landscape mode
  Widget _buildHorizontalGroupChats(
    GroupChatProvider provider,
    AppLocalizations localizations,
  ) {
    final screenWidth = MediaQuery.of(context).size.width;
    double cardWidth;
    if (screenWidth > 1400) {
      cardWidth = 380;
    } else if (screenWidth > 1200) {
      cardWidth = 340;
    } else if (screenWidth > 900) {
      cardWidth = 320;
    } else {
      cardWidth = 280;
    }

    return ListView.builder(
      controller: _groupChatsScrollController,
      scrollDirection: Axis.horizontal,
      physics: const BouncingScrollPhysics(),
      itemCount: provider.groupChats.length,
      padding: const EdgeInsets.symmetric(horizontal: 8),
      itemBuilder: (context, index) {
        final group = provider.groupChats[index];
        return Container(
          width: cardWidth,
          margin: const EdgeInsets.only(right: 24),
          child: _GroupChatSquareCard(
            group: group,
            localizations: localizations,
            onTap: () => _openGroupChat(group),
          ),
        );
      },
    );
  }

  Widget _buildGroupChatCard(GroupChatModel group, AppLocalizations localizations) {
    final deviceType = ResponsiveUtils.getDeviceType(context);
    final shouldUseGrid = deviceType == DeviceType.tablet || 
                         deviceType == DeviceType.desktop || 
                         deviceType == DeviceType.tv;
    
    // Use different card styles based on layout
    if (shouldUseGrid) {
      return _GroupChatSquareCard(
        group: group,
        localizations: localizations,
        onTap: () => _openGroupChat(group),
      );
    } else {
      return _buildGroupChatListCard(group, localizations);
    }
  }

  // List-style card for mobile/narrow screens
  Widget _buildGroupChatListCard(GroupChatModel group, AppLocalizations localizations) {
    final fontScale = ResponsiveUtils.getFontSizeScale(context);
    
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      color: AppTheme.midnightPurple.withValues(alpha: 0.7),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(
          color: AppTheme.warmGold.withValues(alpha: 0.3),
          width: 1,
        ),
      ),
      child: InkWell(
        onTap: () => _openGroupChat(group),
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      group.name,
                      style: UkrainianFontUtils.cinzelWithUkrainianSupport(
                        text: group.name,
                        fontSize: 18 * fontScale,
                        fontWeight: FontWeight.bold,
                        color: AppTheme.warmGold,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  Icon(
                    Icons.group,
                    color: AppTheme.warmGold.withValues(alpha: 0.7),
                    size: 20 * fontScale,
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                localizations.membersCount.replaceAll('{count}', group.characterIds.length.toString()),
                style: UkrainianFontUtils.latoWithUkrainianSupport(
                  text: '${group.characterIds.length} members',
                  fontSize: 14 * fontScale,
                  color: AppTheme.silverMist.withValues(alpha: 0.7),
                ),
              ),
              if (group.messages.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(
                  group.messages.last.content,
                  style: UkrainianFontUtils.latoWithUkrainianSupport(
                    text: group.messages.last.content,
                    fontSize: 12 * fontScale,
                    color: AppTheme.silverMist.withValues(alpha: 0.5),
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCreateGroupChatButton(AppLocalizations localizations) {
    final deviceType = ResponsiveUtils.getDeviceType(context);
    final fontScale = ResponsiveUtils.getFontSizeScale(context);
    final shouldUseGrid = deviceType == DeviceType.tablet || 
                         deviceType == DeviceType.desktop || 
                         deviceType == DeviceType.tv;
    
    return Container(
      constraints: shouldUseGrid 
          ? const BoxConstraints(maxWidth: 400)
          : null,
      width: shouldUseGrid ? null : double.infinity,
      child: ElevatedButton.icon(
        onPressed: _createNewGroupChat,
        style: ElevatedButton.styleFrom(
          backgroundColor: AppTheme.warmGold,
          foregroundColor: AppTheme.deepNavy,
          padding: EdgeInsets.symmetric(
            vertical: shouldUseGrid ? 20 : 16,
            horizontal: shouldUseGrid ? 24 : 16,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        icon: Icon(
          Icons.add_circle_outline,
          size: (shouldUseGrid ? 22 : 20) * fontScale,
        ),
        label: Text(
          localizations.createGroupChat,
          style: UkrainianFontUtils.latoWithUkrainianSupport(
            text: localizations.createGroupChat,
            fontSize: (shouldUseGrid ? 18 : 16) * fontScale,
            fontWeight: FontWeight.bold,
            color: AppTheme.deepNavy,
          ),
        ),
      ),
    );
  }

  void _createNewGroupChat() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const CharacterSelectionScreen(),
      ),
    );
  }

  void _openGroupChat(GroupChatModel group) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => GroupChatScreen(groupId: group.id),
      ),
    ).then((_) {
      // Always return to Explore tab after closing any chat
      _pageController.jumpToPage(0);
      setState(() {
        _selectedIndex = 0;
      });
    });
  }

  // Your Twins tab with user's digital twins
  Widget _buildYourTwinsTab(AppLocalizations localizations) {
    return Consumer<CharactersProvider>(
      builder: (context, provider, child) {
        if (provider.isLoading) {
          return Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(
                  width: 40,
                  height: 40,
                  child: CircularProgressIndicator(
                    valueColor: AlwaysStoppedAnimation<Color>(
                      AppTheme.warmGold,
                    ),
                    strokeWidth: 2,
                    backgroundColor: AppTheme.deepNavy,
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  localizations.accessingDataStorage,
                  style: UkrainianFontUtils.cinzelWithUkrainianSupport(
                    text: localizations.accessingDataStorage,
                    fontSize: 14,
                    color: AppTheme.warmGold,
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
          );
        }

        final characters = provider.characters;

        if (characters.isEmpty) {
          return _buildEmptyState(context, localizations);
        }

        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child:
              ResponsiveUtils.shouldUseWideLayout(context)
                  ? _buildHorizontalGallery(characters, isExploreTab: false)
                  : _buildGridGallery(characters, isExploreTab: false),
        );
      },
    );
  }

  Widget _buildGridGallery(List<dynamic> items, {required bool isExploreTab}) {
    return GridView.builder(
      key: PageStorageKey(isExploreTab ? 'exploreTab' : 'yourTwinsTab'),
      controller:
          isExploreTab ? _exploreScrollController : _yourTwinsScrollController,
      padding: EdgeInsets.symmetric(
        horizontal: ResponsiveUtils.getGridSpacing(context),
        vertical: 24,
      ),
      physics: const BouncingScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: ResponsiveUtils.getGridCrossAxisCount(context),
        childAspectRatio: ResponsiveUtils.getGridChildAspectRatio(context),
        crossAxisSpacing: ResponsiveUtils.getGridSpacing(context),
        mainAxisSpacing: ResponsiveUtils.getGridSpacing(context),
      ),
      itemCount: items.length,
      itemBuilder: (context, index) {
        final item = items[index];

        if (isExploreTab) {
          final famousPerson = item as Map<String, dynamic>;
          return _FamousPersonCard(
            key: ValueKey('famous_person_${famousPerson['name']}'),
            name: famousPerson['name'] as String,
            years: famousPerson['years'] as String,
            profession: famousPerson['profession'] as String,
            imageUrl: famousPerson['imageUrl'] as String?,
            isHorizontalLayout: false,
          );
        } else {
          final character = item as CharacterModel;
          return _YourTwinCard(
            key: ValueKey(character.id),
            character: character,
            isHorizontalLayout: false,
          );
        }
      },
    );
  }

  Widget _buildEmptyState(
    BuildContext context,
    AppLocalizations localizations,
  ) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Empty state illustration
          Container(
            width: 160,
            height: 160,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  AppTheme.midnightPurple.withValues(alpha: 0.4),
                  AppTheme.deepNavy.withValues(alpha: 0.3),
                ],
              ),
              border: Border.all(
                color: AppTheme.warmGold.withValues(alpha: 0.4),
                width: 2,
              ),
              boxShadow: [
                BoxShadow(
                  color: AppTheme.warmGold.withValues(alpha: 0.2),
                  blurRadius: 10,
                  spreadRadius: 0,
                ),
              ],
            ),
            child: Icon(
              Icons.person_add_outlined,
              size: 80,
              color: AppTheme.warmGold.withValues(alpha: 0.7),
            ),
          ),
          const SizedBox(height: 32),

          // Empty state message
          Text(
            localizations.noDigitalTwinsDetected,
            style: UkrainianFontUtils.cinzelWithUkrainianSupport(
              text: localizations.noDigitalTwinsDetected,
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: AppTheme.warmGold,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 16),

          // Description text
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40),
            child: Text(
              localizations.createNewTwinDescription,
              textAlign: TextAlign.center,
              style: UkrainianFontUtils.latoWithUkrainianSupport(
                text: localizations.createNewTwinDescription,
                fontSize: 16,
                color: AppTheme.silverMist.withValues(alpha: 0.8),
                height: 1.5,
              ),
            ),
          ),
          const SizedBox(height: 32),

          // Create button
          MouseRegion(
            cursor: SystemMouseCursors.click,
            child: GestureDetector(
              onTap: () => _onAddCharacter(context),
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 28,
                  vertical: 16,
                ),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      AppTheme.warmGold.withValues(alpha: 0.9),
                      AppTheme.warmGold.withValues(alpha: 0.7),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(28),
                  boxShadow: [
                    BoxShadow(
                      color: AppTheme.warmGold.withValues(alpha: 0.4),
                      blurRadius: 15,
                      spreadRadius: 0,
                      offset: const Offset(0, 4),
                    ),
                    BoxShadow(
                      color: AppTheme.deepNavy.withValues(alpha: 0.3),
                      blurRadius: 8,
                      spreadRadius: 0,
                      offset: const Offset(0, 2),
                    ),
                  ],
                  border: Border.all(
                    color: AppTheme.warmGold.withValues(alpha: 0.6),
                    width: 1,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(
                      Icons.add_circle_outline,
                      size: 22,
                      color: AppTheme.deepNavy.withValues(alpha: 0.9),
                    ),
                    const SizedBox(width: 12),
                    Text(
                      localizations.createNewTwin,
                      style: UkrainianFontUtils.cinzelWithUkrainianSupport(
                        text: localizations.createNewTwin,
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: AppTheme.deepNavy,
                        letterSpacing: 1.2,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _onCharacterSelected(BuildContext context, CharacterModel character) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CharacterChatScreen(characterId: character.id),
      ),
    ).then((_) {
      // Always return to Explore tab after closing any chat
      _pageController.jumpToPage(0);
      setState(() {
        _selectedIndex = 0;
      });
    });
  }

  void _onAddCharacter(BuildContext context) async {
    final route = Platform.isIOS
        ? CupertinoPageRoute(builder: (context) => const InterviewScreen())
        : MaterialPageRoute(builder: (context) => const InterviewScreen());

    final result = await Navigator.push(context, route);

    // Always return to Explore tab after closing Interview
    _pageController.jumpToPage(0);
    setState(() {
      _selectedIndex = 0;
    });

    if (result != null && result is CharacterModel) {
      await Provider.of<CharactersProvider>(
        context,
        listen: false,
      ).addCharacter(result);
    }
  }

  // Kept for potential reuse
  // ignore: unused_element
  String _formatDate(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);
    final localizations = AppLocalizations.of(context);

    if (difference.inDays == 0) return localizations.today;
    if (difference.inDays == 1) return localizations.yesterday;
    if (difference.inDays < 7) {
      return '${difference.inDays} ${localizations.daysAgo}';
    }
    return '${dateTime.day}/${dateTime.month}/${dateTime.year}';
  }

  // Card for displaying a user-created character
  Widget _YourTwinCard({
    required Key key,
    required CharacterModel character,
    required bool isHorizontalLayout,
  }) {
    // Access localizations within closures via AppLocalizations.of(context)

    return _YourTwinCardWidget(
      key: key,
      character: character,
      isHorizontalLayout: isHorizontalLayout,
      onTap: () => _onCharacterSelected(context, character),
    );
  }

  Widget _buildHorizontalGallery(
    List<dynamic> items, {
    required bool isExploreTab,
  }) {
    final screenWidth = MediaQuery.of(context).size.width;

    // Calculate card dimensions based on screen width
    double cardWidth = screenWidth > 1200 ? 320 : 280;
    double cardHeight = cardWidth * 1.4; // Maintain aspect ratio

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Gallery title
        if (items.isNotEmpty) ...[
          Padding(
            padding: const EdgeInsets.only(left: 8, bottom: 16),
            child: Text(
              isExploreTab ? 'Historical Figures' : 'Your Digital Twins',
              style: UkrainianFontUtils.cinzelWithUkrainianSupport(
                text:
                    isExploreTab ? 'Historical Figures' : 'Your Digital Twins',
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: AppTheme.warmGold,
                letterSpacing: 1.5,
              ),
            ),
          ),
        ],

        // Horizontal scrolling gallery with smoother scroll physics
        Expanded(
          child: ListView.builder(
            controller:
                isExploreTab
                    ? _exploreScrollController
                    : _yourTwinsScrollController,
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(
              decelerationRate: ScrollDecelerationRate.fast,
            ),
            padding: const EdgeInsets.symmetric(horizontal: 8),
            itemCount: items.length,
            itemBuilder: (context, index) {
              final item = items[index];

              return Container(
                width: cardWidth,
                height: cardHeight,
                margin: const EdgeInsets.only(right: 24),
                child:
                    isExploreTab
                        ? _FamousPersonCard(
                          key: ValueKey('famous_person_${item['name']}'),
                          name: item['name'] as String,
                          years: item['years'] as String,
                          profession: item['profession'] as String,
                          imageUrl: item['imageUrl'] as String?,
                          isHorizontalLayout: true,
                        )
                        : _YourTwinCard(
                          key: ValueKey('character_${item.id}'),
                          character: item as CharacterModel,
                          isHorizontalLayout: true,
                        ),
              );
            },
          ),
        ),
      ],
    );
  }
}

// Extracted as a separate stateful widget for better performance through memoization
class _FamousPersonCard extends StatefulWidget {
  final String name;
  final String years;
  final String profession;
  final String? imageUrl;
  final bool isHorizontalLayout;

  const _FamousPersonCard({
    Key? key,
    required this.name,
    required this.years,
    required this.profession,
    this.imageUrl,
    this.isHorizontalLayout = false,
  }) : super(key: key);

  @override
  State<_FamousPersonCard> createState() => _FamousPersonCardState();
}

class _FamousPersonCardState extends State<_FamousPersonCard>
    with SingleTickerProviderStateMixin {
  // Animation controller for hover effects
  late AnimationController _controller;
  late Animation<double> _glowAnimation;
  late Animation<double> _scaleAnimation;
  bool _isHovering = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 400),
      vsync: this,
    );

    _glowAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));

    _scaleAnimation = Tween<double>(
      begin: 1.0,
      end: 1.03,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutQuad));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Create a custom accent color for the card
    final Color accentColor = AppTheme.warmGold;
    // Reserve space at the bottom for text so it never overlays the mask image
    final double reservedFooterHeight = widget.isHorizontalLayout ? 96 : 84;

    return GestureDetector(
      onTap: () => _navigateToProfile(context),
      child: MouseRegion(
        onEnter:
            (_) => setState(() {
              _isHovering = true;
              _controller.forward();
            }),
        onExit:
            (_) => setState(() {
              _isHovering = false;
              _controller.reverse();
            }),
        child: AnimatedBuilder(
          animation: _controller,
          builder: (context, child) {
            return Transform.scale(
              scale: _isHovering ? _scaleAnimation.value : 1.0,
              child: Stack(
                children: [
                  // Main card with glowing effect
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [AppTheme.midnightPurple, AppTheme.deepNavy],
                      ),
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color:
                              _isHovering
                                  ? accentColor.withValues(alpha: 0.8)
                                  : accentColor.withValues(alpha: 0.4),
                          blurRadius: _isHovering ? 20 : 12,
                          spreadRadius: _isHovering ? 3 : 1,
                          offset: Offset(0, _isHovering ? 8 : 4),
                        ),
                        BoxShadow(
                          color: AppTheme.deepNavy.withValues(alpha: 0.6),
                          blurRadius: 10,
                          spreadRadius: 0,
                          offset: const Offset(0, 2),
                        ),
                      ],
                      border: Border.all(
                        color:
                            _isHovering
                                ? accentColor.withValues(alpha: 0.9)
                                : accentColor.withValues(alpha: 0.6),
                        width: _isHovering ? 2.5 : 2.0,
                      ),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(22),
                      child: child,
                    ),
                  ),

                  // Pulse ring animation when hovering
                  if (_isHovering)
                    AnimatedBuilder(
                      animation: _glowAnimation,
                      builder: (context, _) {
                        return Positioned.fill(
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(20),
                            child: CustomPaint(
                              painter: PulseRingPainter(
                                progress: _glowAnimation.value,
                                color: accentColor,
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                ],
              ),
            );
          },
          child: ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: Stack(
              children: [
                // Background image if available
                if (widget.imageUrl != null)
                  Positioned.fill(
                    bottom: reservedFooterHeight,
                    child: Stack(
                      children: [
                        // Dramatic background for masks
                        Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [
                                AppTheme.midnightPurple,
                                AppTheme.deepNavy,
                              ],
                            ),
                          ),
                        ),
                        // Centered mask image with consistent alignment across cards
                        Center(
                          child: FractionallySizedBox(
                            widthFactor: widget.isHorizontalLayout ? 0.86 : 0.90,
                            heightFactor: widget.isHorizontalLayout ? 0.76 : 0.72,
                            child: FittedBox(
                              fit: BoxFit.contain,
                              alignment: Alignment.center,
                              child: Image.asset(
                                widget.imageUrl!,
                                fit: BoxFit.contain,
                                alignment: Alignment.center,
                              ),
                            ),
                          ),
                        ),
                        // Subtle spotlight effect overlay
                        Positioned.fill(
                          child: Container(
                            decoration: BoxDecoration(
                              gradient: RadialGradient(
                                center: Alignment.center,
                                radius: 1.2,
                                colors: [
                                  Colors.transparent,
                                  AppTheme.deepNavy.withValues(alpha: 0.4),
                                ],
                                stops: const [0.6, 1.0],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  )
                // If no image, use gradient background
                else
                  Positioned.fill(
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                          colors: [AppTheme.deepNavy, AppTheme.midnightPurple],
                        ),
                      ),
                      child: Center(
                        child: Icon(
                          Icons.person_outline,
                          size: widget.isHorizontalLayout ? 120 : 80,
                          color: accentColor.withValues(alpha: 0.5),
                        ),
                      ),
                    ),
                  ),

                // Gradient overlay for better text contrast
                Positioned.fill(
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.transparent,
                          AppTheme.deepNavy.withValues(alpha: 0.7),
                          AppTheme.deepNavy.withValues(alpha: 0.9),
                        ],
                        stops: const [0.6, 0.85, 1.0],
                      ),
                    ),
                  ),
                ),

                // Card content
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: Container(
                    padding: EdgeInsets.all(
                      widget.isHorizontalLayout ? 20 : 16,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Digital twin name (adaptive, no ellipsis)
                        AdaptiveTextPresets.characterName(
                          text: widget.name,
                          baseStyle: UkrainianFontUtils
                              .cinzelWithUkrainianSupport(
                            text: widget.name,
                            fontSize:
                                widget.isHorizontalLayout ? 22 : 18,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 0.5,
                            color: AppTheme.warmGold,
                            shadows: [
                              Shadow(
                                color: AppTheme.warmGold
                                    .withValues(alpha: 0.5),
                                blurRadius: 4,
                                offset: const Offset(0, 1),
                              ),
                            ],
                          ),
                          isHorizontalLayout: widget.isHorizontalLayout,
                        ),

                        SizedBox(height: widget.isHorizontalLayout ? 8 : 6),

                        // Years
                        Row(
                          children: [
                            // Pulsing indicator
                            _buildPulsingDot(),
                            const SizedBox(width: 8),
                            Expanded(
                              child: AdaptiveTextPresets.metadata(
                                text: widget.years,
                                baseStyle: UkrainianFontUtils
                                    .cinzelWithUkrainianSupport(
                                  text: widget.years,
                                  fontSize: widget.isHorizontalLayout ? 16 : 14,
                                  color: AppTheme.warmGold,
                                  letterSpacing: 0.5,
                                  shadows: [
                                    Shadow(
                                      color: AppTheme.warmGold
                                          .withValues(alpha: 0.5),
                                      blurRadius: 4,
                                      offset: const Offset(0, 1),
                                    ),
                                  ],
                                ),
                                isHorizontalLayout: widget.isHorizontalLayout,
                              ),
                            ),
                          ],
                        ),

                        SizedBox(height: widget.isHorizontalLayout ? 12 : 10),

                        // Profession label with elegant styling
                        Container(
                          padding: EdgeInsets.symmetric(
                            horizontal: widget.isHorizontalLayout ? 12 : 8,
                            vertical: widget.isHorizontalLayout ? 6 : 3,
                          ),
                          decoration: BoxDecoration(
                            color: AppTheme.warmGold.withValues(alpha: 0.2),
                            borderRadius: BorderRadius.circular(
                              widget.isHorizontalLayout ? 6 : 4,
                            ),
                            border: Border.all(
                              color: AppTheme.warmGold.withValues(alpha: 0.4),
                              width: 1,
                            ),
                          ),
                          child: AdaptiveTextPresets.label(
                            text: widget.profession,
                            baseStyle: UkrainianFontUtils
                                .cinzelWithUkrainianSupport(
                              text: widget.profession,
                              fontSize:
                                  widget.isHorizontalLayout ? 13 : 11,
                              fontWeight: FontWeight.w600,
                              letterSpacing: 0.5,
                              color: AppTheme.warmGold,
                            ),
                            isHorizontalLayout: widget.isHorizontalLayout,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                // Add a subtle "Coming Soon" overlay for unreleased characters
                // Only shown if the _isReleased flag is specifically set to false
                if (_isHovering)
                  Positioned(
                    right: 16,
                    top: 16,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: AppTheme.warmGold.withValues(alpha: 0.9),
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: AppTheme.deepNavy.withValues(alpha: 0.2),
                            blurRadius: 4,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.arrow_forward,
                            color: AppTheme.midnightPurple.withValues(
                              alpha: 0.9,
                            ),
                            size: 14,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            'View',
                            style:
                                UkrainianFontUtils.cinzelWithUkrainianSupport(
                                  text: 'View',
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color: AppTheme.midnightPurple,
                                ),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPulsingDot() {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        return Container(
          width: 6,
          height: 6,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: AppTheme.warmGold,
            boxShadow: [
              BoxShadow(
                color: AppTheme.warmGold.withValues(
                  alpha: 0.5 * _glowAnimation.value,
                ),
                blurRadius: 4 * _glowAnimation.value,
                spreadRadius: 1 * _glowAnimation.value,
              ),
            ],
          ),
        );
      },
    );
  }

  void _navigateToProfile(BuildContext context) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder:
            (context) => FamousCharacterProfileScreen(
              name: widget.name,
              years: widget.years,
              profession: widget.profession,
              imageUrl: widget.imageUrl,
            ),
      ),
    );
  }
}

// Character card widget for user-created characters
class _YourTwinCardWidget extends StatefulWidget {
  final CharacterModel character;
  final bool isHorizontalLayout;
  final VoidCallback onTap;

  const _YourTwinCardWidget({
    Key? key,
    required this.character,
    required this.isHorizontalLayout,
    required this.onTap,
  }) : super(key: key);

  @override
  State<_YourTwinCardWidget> createState() => _YourTwinCardWidgetState();
}

class _YourTwinCardWidgetState extends State<_YourTwinCardWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _glowAnimation;
  late Animation<double> _scaleAnimation;
  bool _isHovering = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 400),
      vsync: this,
    );

    _glowAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));

    _scaleAnimation = Tween<double>(
      begin: 1.0,
      end: 1.03,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutQuad));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final Color accentColor = widget.character.accentColor;
    final String formattedDate = _formatDate(widget.character.createdAt);

    return GestureDetector(
      onTap: widget.onTap,
      child: MouseRegion(
        onEnter:
            (_) => setState(() {
              _isHovering = true;
              _controller.forward();
            }),
        onExit:
            (_) => setState(() {
              _isHovering = false;
              _controller.reverse();
            }),
        child: AnimatedBuilder(
          animation: _controller,
          builder: (context, child) {
            return Transform.scale(
              scale: _isHovering ? _scaleAnimation.value : 1.0,
              child: Stack(
                children: [
                  // Main card with glowing effect
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [AppTheme.midnightPurple, AppTheme.deepNavy],
                      ),
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color:
                              _isHovering
                                  ? accentColor.withValues(alpha: 0.8)
                                  : accentColor.withValues(alpha: 0.4),
                          blurRadius: _isHovering ? 20 : 12,
                          spreadRadius: _isHovering ? 3 : 1,
                          offset: Offset(0, _isHovering ? 8 : 4),
                        ),
                        BoxShadow(
                          color: AppTheme.deepNavy.withValues(alpha: 0.6),
                          blurRadius: 10,
                          spreadRadius: 0,
                          offset: const Offset(0, 2),
                        ),
                      ],
                      border: Border.all(
                        color:
                            _isHovering
                                ? accentColor.withValues(alpha: 0.9)
                                : accentColor.withValues(alpha: 0.6),
                        width: _isHovering ? 2.5 : 2.0,
                      ),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(18),
                      child: child,
                    ),
                  ),

                  // Pulse ring animation when hovering
                  if (_isHovering)
                    AnimatedBuilder(
                      animation: _glowAnimation,
                      builder: (context, _) {
                        return Positioned.fill(
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(20),
                            child: CustomPaint(
                              painter: PulseRingPainter(
                                progress: _glowAnimation.value,
                                color: accentColor,
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                ],
              ),
            );
          },
          child: ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: Stack(
              children: [
                // Background gradient
                Positioned.fill(
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [AppTheme.deepNavy, AppTheme.midnightPurple],
                      ),
                    ),
                  ),
                ),

                // Character icon/avatar in the center
                Positioned.fill(
                  child: Container(
                    padding: EdgeInsets.all(
                      widget.isHorizontalLayout ? 20 : 16,
                    ),
                    child: Center(
                      child: ImageUtils.buildCharacterAvatar(
                        imagePath: widget.character.userImagePath,
                        size: widget.isHorizontalLayout ? 80 : 60,
                        fallbackIcon: widget.character.icon,
                        fallbackText: widget.character.name,
                        backgroundColor: accentColor.withValues(alpha: 0.2),
                        foregroundColor: accentColor,
                      ),
                    ),
                  ),
                ),

                // Gradient overlay for better text contrast
                Positioned.fill(
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.transparent,
                          AppTheme.deepNavy.withValues(alpha: 0.7),
                          AppTheme.deepNavy.withValues(alpha: 0.9),
                        ],
                        stops: const [0.6, 0.85, 1.0],
                      ),
                    ),
                  ),
                ),

                // Card content
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: Container(
                    padding: EdgeInsets.all(
                      widget.isHorizontalLayout ? 20 : 16,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Character name (adaptive, no ellipsis)
                        AdaptiveTextPresets.characterName(
                          text: widget.character.name,
                          baseStyle: UkrainianFontUtils
                              .cinzelWithUkrainianSupport(
                            text: widget.character.name,
                            fontSize:
                                widget.isHorizontalLayout ? 22 : 18,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 0.5,
                            color: AppTheme.warmGold,
                            shadows: [
                              Shadow(
                                color: AppTheme.warmGold
                                    .withValues(alpha: 0.5),
                                blurRadius: 4,
                                offset: const Offset(0, 1),
                              ),
                            ],
                          ),
                          isHorizontalLayout: widget.isHorizontalLayout,
                        ),

                        SizedBox(height: widget.isHorizontalLayout ? 8 : 6),

                        // Created date
                        Row(
                          children: [
                            // Pulsing indicator
                            _buildPulsingDot(accentColor),
                            const SizedBox(width: 8),
                            Expanded(
                              child: AdaptiveTextPresets.metadata(
                                text:
                                    '${AppLocalizations.of(context).created} $formattedDate',
                                baseStyle: UkrainianFontUtils
                                    .cinzelWithUkrainianSupport(
                                  text:
                                      '${AppLocalizations.of(context).created} $formattedDate',
                                  fontSize:
                                      widget.isHorizontalLayout ? 14 : 12,
                                  color: AppTheme.silverMist
                                      .withValues(alpha: 0.8),
                                  letterSpacing: 0.5,
                                ),
                                isHorizontalLayout: widget.isHorizontalLayout,
                              ),
                            ),
                          ],
                        ),

                        SizedBox(height: widget.isHorizontalLayout ? 12 : 10),

                        // AI Model label
                        Container(
                          padding: EdgeInsets.symmetric(
                            horizontal: widget.isHorizontalLayout ? 12 : 8,
                            vertical: widget.isHorizontalLayout ? 6 : 4,
                          ),
                          decoration: BoxDecoration(
                            color: accentColor.withValues(alpha: 0.2),
                            borderRadius: BorderRadius.circular(
                              widget.isHorizontalLayout ? 6 : 4,
                            ),
                            border: Border.all(
                              color: accentColor.withValues(alpha: 0.4),
                              width: 1,
                            ),
                          ),
                          child: Text(
                            _getModelDisplayName(widget.character.model),
                            style:
                                UkrainianFontUtils.cinzelWithUkrainianSupport(
                                  text: _getModelDisplayName(
                                    widget.character.model,
                                  ),
                                  fontSize: widget.isHorizontalLayout ? 12 : 10,
                                  fontWeight: FontWeight.w600,
                                  letterSpacing: 0.5,
                                  color: accentColor,
                                ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                // View indicator when hovering
                if (_isHovering)
                  Positioned(
                    right: 16,
                    top: 16,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: accentColor.withValues(alpha: 0.9),
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: AppTheme.deepNavy.withValues(alpha: 0.2),
                            blurRadius: 4,
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.chat_bubble_outline,
                            color: AppTheme.midnightPurple,
                            size: 14,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            'Chat',
                            style:
                                UkrainianFontUtils.cinzelWithUkrainianSupport(
                                  text: 'Chat',
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color: AppTheme.midnightPurple,
                                ),
                          ),
                        ],
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPulsingDot(Color color) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        return Container(
          width: 6,
          height: 6,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: color,
            boxShadow: [
              BoxShadow(
                color: color.withValues(alpha: 0.5 * _glowAnimation.value),
                blurRadius: 4 * _glowAnimation.value,
                spreadRadius: 1 * _glowAnimation.value,
              ),
            ],
          ),
        );
      },
    );
  }

  String _getModelDisplayName(String modelId) {
    if (modelId.startsWith('local/')) return '本地 AI';
    return modelId == 'deepseek-v4-pro' ? 'DeepSeek V4 Pro' : 'DeepSeek Flash';
  }

  String _formatDate(DateTime dateTime) {
    final now = DateTime.now();
    final difference = now.difference(dateTime);
    final localizations = AppLocalizations.of(context);

    if (difference.inDays == 0) return localizations.today;
    if (difference.inDays == 1) return localizations.yesterday;
    if (difference.inDays < 7)
      return '${difference.inDays} ${localizations.daysAgo}';
    return '${dateTime.day}/${dateTime.month}/${dateTime.year}';
  }
}

// Custom painter for the starfield background effect
class StarfieldPainter extends CustomPainter {
  final int starCount;
  final List<_Star> _stars = [];
  final Random _random = Random(42);
  // ignore: unused_field
  final Paint _goldStarPaint =
      Paint()..color = AppTheme.warmGold.withValues(alpha: 0.8);
  // ignore: unused_field
  final Paint _purpleStarPaint =
      Paint()..color = AppTheme.gentlePurple.withValues(alpha: 0.6);
  // ignore: unused_field
  final Paint _silverStarPaint =
      Paint()..color = AppTheme.silverMist.withValues(alpha: 0.7);

  StarfieldPainter({this.starCount = 100}) {
    // Pre-generate stars only once for performance
    _generateStars();
  }

  void _generateStars() {
    for (int i = 0; i < starCount; i++) {
      final starType = _random.nextInt(10); // 0-9 random value for star type
      final Color starColor;

      // Distribute colors: 20% gold, 30% purple, 50% silver
      if (starType < 2) {
        starColor = AppTheme.warmGold;
      } else if (starType < 5) {
        starColor = AppTheme.gentlePurple;
      } else {
        starColor = AppTheme.silverMist;
      }

      _stars.add(
        _Star(
          x: _random.nextDouble(),
          y: _random.nextDouble(),
          size: _random.nextDouble() * 2 + 0.5,
          opacity: _random.nextDouble() * 0.7 + 0.3,
          color: starColor,
        ),
      );
    }
  }

  @override
  void paint(Canvas canvas, Size size) {
    for (final star in _stars) {
      final x = star.x * size.width;
      final y = star.y * size.height;

      final Paint starPaint =
          Paint()..color = star.color.withValues(alpha: star.opacity);

      canvas.drawCircle(Offset(x, y), star.size, starPaint);

      // Add subtle glow to larger stars
      if (star.size > 1.2) {
        final glowPaint =
            Paint()
              ..color = star.color.withOpacity(star.opacity * 0.3)
              ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 3);

        canvas.drawCircle(Offset(x, y), star.size * 2, glowPaint);
      }
    }
  }

  @override
  bool shouldRepaint(StarfieldPainter oldDelegate) => false; // Never repaint
}

class _Star {
  final double x;
  final double y;
  final double size;
  final double opacity;
  final Color color;

  _Star({
    required this.x,
    required this.y,
    required this.size,
    required this.opacity,
    required this.color,
  });
}

// Square card widget for group chats on wide screens
class _GroupChatSquareCard extends StatefulWidget {
  final GroupChatModel group;
  final AppLocalizations localizations;
  final VoidCallback onTap;

  const _GroupChatSquareCard({
    Key? key,
    required this.group,
    required this.localizations,
    required this.onTap,
  }) : super(key: key);

  @override
  State<_GroupChatSquareCard> createState() => _GroupChatSquareCardState();
}

class _GroupChatSquareCardState extends State<_GroupChatSquareCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _glowAnimation;
  late Animation<double> _scaleAnimation;
  bool _isHovering = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 400),
      vsync: this,
    );

    _glowAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));

    _scaleAnimation = Tween<double>(
      begin: 1.0,
      end: 1.03,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOutQuad));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final Color accentColor = AppTheme.warmGold;
    final fontScale = ResponsiveUtils.getFontSizeScale(context);

    return GestureDetector(
      onTap: widget.onTap,
      child: MouseRegion(
        onEnter: (_) => setState(() {
          _isHovering = true;
          _controller.forward();
        }),
        onExit: (_) => setState(() {
          _isHovering = false;
          _controller.reverse();
        }),
        child: AnimatedBuilder(
          animation: _controller,
          builder: (context, child) {
            return Transform.scale(
              scale: _isHovering ? _scaleAnimation.value : 1.0,
              child: Stack(
                children: [
                  // Main card with glowing effect
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [AppTheme.midnightPurple, AppTheme.deepNavy],
                      ),
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: _isHovering
                              ? accentColor.withValues(alpha: 0.8)
                              : accentColor.withValues(alpha: 0.4),
                          blurRadius: _isHovering ? 20 : 12,
                          spreadRadius: _isHovering ? 3 : 1,
                          offset: Offset(0, _isHovering ? 8 : 4),
                        ),
                        BoxShadow(
                          color: AppTheme.deepNavy.withValues(alpha: 0.6),
                          blurRadius: 10,
                          spreadRadius: 0,
                          offset: const Offset(0, 2),
                        ),
                      ],
                      border: Border.all(
                        color: _isHovering
                            ? accentColor.withValues(alpha: 0.9)
                            : accentColor.withValues(alpha: 0.6),
                        width: _isHovering ? 2.5 : 2.0,
                      ),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(18),
                      child: child,
                    ),
                  ),

                  // Pulse ring animation when hovering
                  if (_isHovering)
                    AnimatedBuilder(
                      animation: _glowAnimation,
                      builder: (context, _) {
                        return Positioned.fill(
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(20),
                            child: CustomPaint(
                              painter: PulseRingPainter(
                                progress: _glowAnimation.value,
                                color: accentColor,
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                ],
              ),
            );
          },
          child: ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: Stack(
              children: [
                // Background gradient
                Positioned.fill(
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                        colors: [AppTheme.deepNavy, AppTheme.midnightPurple],
                      ),
                    ),
                  ),
                ),

                // Group icon in the center
                Positioned.fill(
                  child: Container(
                    padding: const EdgeInsets.all(20),
                    child: Center(
                      child: Container(
                        width: 80,
                        height: 80,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: accentColor.withValues(alpha: 0.2),
                          border: Border.all(
                            color: accentColor.withValues(alpha: 0.6),
                            width: 2,
                          ),
                        ),
                        child: Icon(
                          Icons.groups,
                          size: 40,
                          color: accentColor,
                        ),
                      ),
                    ),
                  ),
                ),

                // Gradient overlay for better text contrast
                Positioned.fill(
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.transparent,
                          AppTheme.deepNavy.withValues(alpha: 0.7),
                          AppTheme.deepNavy.withValues(alpha: 0.9),
                        ],
                        stops: const [0.6, 0.85, 1.0],
                      ),
                    ),
                  ),
                ),

                // Card content at bottom
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: Container(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Group name
                        Text(
                          widget.group.name,
                          style: UkrainianFontUtils.cinzelWithUkrainianSupport(
                            text: widget.group.name,
                            fontSize: 22 * fontScale,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 0.5,
                            color: AppTheme.warmGold,
                            shadows: [
                              Shadow(
                                color: AppTheme.warmGold.withValues(alpha: 0.5),
                                blurRadius: 4,
                                offset: const Offset(0, 1),
                              ),
                            ],
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),

                        const SizedBox(height: 8),

                        // Member count
                        Row(
                          children: [
                            Icon(
                              Icons.people_outline,
                              size: 16 * fontScale,
                              color: AppTheme.silverMist.withValues(alpha: 0.8),
                            ),
                            const SizedBox(width: 6),
                            Text(
                              widget.localizations.membersCount.replaceAll('{count}', widget.group.characterIds.length.toString()),
                              style: UkrainianFontUtils.latoWithUkrainianSupport(
                                text: '${widget.group.characterIds.length} members',
                                fontSize: 14 * fontScale,
                                color: AppTheme.silverMist.withValues(alpha: 0.8),
                                letterSpacing: 0.5,
                              ),
                            ),
                          ],
                        ),

                        // Last message (if any)
                        if (widget.group.messages.isNotEmpty) ...[
                          const SizedBox(height: 6),
                          Text(
                            widget.group.messages.last.content,
                            style: UkrainianFontUtils.latoWithUkrainianSupport(
                              text: widget.group.messages.last.content,
                              fontSize: 12 * fontScale,
                              color: AppTheme.silverMist.withValues(alpha: 0.6),
                              letterSpacing: 0.3,
                            ),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ],
                      ],
                    ),
                  ),
                ),

                // Activity indicator (pulsing dot)
                Positioned(
                  top: 16,
                  right: 16,
                  child: _buildActivityIndicator(),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildActivityIndicator() {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        return Container(
          width: 8,
          height: 8,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: widget.group.messages.isNotEmpty 
                ? AppTheme.warmGold
                : AppTheme.silverMist.withValues(alpha: 0.5),
            boxShadow: [
              BoxShadow(
                color: (widget.group.messages.isNotEmpty 
                    ? AppTheme.warmGold 
                    : AppTheme.silverMist).withValues(
                  alpha: 0.5 * (_isHovering ? _glowAnimation.value : 0.3),
                ),
                blurRadius: 4 * (_isHovering ? _glowAnimation.value : 1),
                spreadRadius: 1 * (_isHovering ? _glowAnimation.value : 1),
              ),
            ],
          ),
        );
      },
    );
  }
}
