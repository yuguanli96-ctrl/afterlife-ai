import 'package:flutter/material.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/utils/ukrainian_font_utils.dart';
import 'package:provider/provider.dart';
import '../../../features/providers/language_provider.dart';
import '../../../l10n/app_localizations.dart';

class LanguagePage extends StatefulWidget {
  const LanguagePage({super.key});

  @override
  State<LanguagePage> createState() => _LanguagePageState();
}

class _LanguagePageState extends State<LanguagePage>
    with TickerProviderStateMixin {
  late AnimationController animationController;
  late Animation<Offset> titleAnimation;
  late Animation<Offset> contentAnimation;

  @override
  void initState() {
    super.initState();
    animationController = AnimationController(
      duration: const Duration(milliseconds: 1500),
      vsync: this,
    );

    titleAnimation = Tween<Offset>(
      begin: const Offset(0, -1),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: animationController,
      curve: const Interval(0.0, 0.6, curve: Curves.easeOutCubic),
    ));

    contentAnimation = Tween<Offset>(
      begin: const Offset(0, 1),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: animationController,
      curve: const Interval(0.2, 0.8, curve: Curves.easeOutCubic),
    ));

    animationController.forward();
  }

  @override
  void dispose() {
    animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final titleAnimation = Tween<Offset>(
      begin: const Offset(0, -0.1),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(
        parent: animationController,
        curve: const Interval(0.0, 0.6, curve: Curves.easeOutCubic),
      ),
    );

    final contentAnimation = Tween<Offset>(
      begin: const Offset(0, 0.1),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(
        parent: animationController,
        curve: const Interval(0.3, 1.0, curve: Curves.easeOutCubic),
      ),
    );

    final localizations = AppLocalizations.of(context);
    final languageProvider = Provider.of<LanguageProvider>(context);

    final languages = [
      {'code': 'zh', 'name': '简体中文'},
      {'code': 'en', 'name': localizations.languageEnglish},
      {'code': 'es', 'name': localizations.languageSpanish},
      {'code': 'fr', 'name': localizations.languageFrench},
      {'code': 'de', 'name': localizations.languageGerman},
      {'code': 'it', 'name': localizations.languageItalian},
      {'code': 'ja', 'name': localizations.languageJapanese},
      {'code': 'ko', 'name': localizations.languageKorean},
      {'code': 'uk', 'name': localizations.languageUkrainian},
      {'code': 'ru', 'name': localizations.languageRussian},
    ];

    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            SlideTransition(
              position: titleAnimation,
              child: FadeTransition(
                opacity: CurvedAnimation(
                  parent: animationController,
                  curve: const Interval(0.0, 0.7, curve: Curves.easeOut),
                ),
                child: Column(
                  children: [
                    const SizedBox(height: 8),
                    Text(
                      localizations.language.toUpperCase(),
                      style: UkrainianFontUtils.cinzelWithUkrainianSupport(
                        text: localizations.language.toUpperCase(),
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 3.0,
                        color: AppTheme.silverMist,
                        shadows: [
                          Shadow(
                            blurRadius: 10.0,
                            color: AppTheme.warmGold.withValues(alpha: 0.8),
                            offset: const Offset(0, 2),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      localizations.languageDescription,
                      textAlign: TextAlign.center,
                      style: UkrainianFontUtils.latoWithUkrainianSupport(
                        text: localizations.languageDescription,
                        fontSize: 16,
                        fontWeight: FontWeight.w300,
                        color: AppTheme.silverMist.withValues(alpha: 0.9),
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 32),
            Expanded(
              child: SlideTransition(
                position: contentAnimation,
                child: FadeTransition(
                  opacity: CurvedAnimation(
                    parent: animationController,
                    curve: const Interval(0.3, 1.0),
                  ),
                  child: GridView.builder(
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      childAspectRatio: 2.5,
                      crossAxisSpacing: 16,
                      mainAxisSpacing: 16,
                    ),
                    itemCount: languages.length,
                    itemBuilder: (context, index) {
                      final language = languages[index];
                      final isSelected = languageProvider.currentLanguageCode == language['code'];
                      
                      return Material(
                        color: Colors.transparent,
                        child: InkWell(
                          onTap: () {
                            languageProvider.setLanguage(language['code']!);
                          },
                          borderRadius: BorderRadius.circular(12),
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: isSelected ? AppTheme.warmGold : AppTheme.warmGold.withValues(alpha: 0.3),
                                width: isSelected ? 2 : 1,
                              ),
                              color: isSelected 
                                ? AppTheme.warmGold.withValues(alpha: 0.1)
                                : AppTheme.midnightPurple.withValues(alpha: 0.3),
                            ),
                            child: Center(
                              child: Text(
                                language['name']!,
                                style: UkrainianFontUtils.latoWithUkrainianSupport(
                                  text: language['name']!,
                                  fontSize: 16,
                                  fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                                  color: isSelected ? AppTheme.warmGold : AppTheme.silverMist,
                                ),
                              ),
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
} 